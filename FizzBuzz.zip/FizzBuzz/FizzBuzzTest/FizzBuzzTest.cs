using NUnit.Framework;

namespace FizzBuzzTest
{
    public class Tests
    {
        FizzBuzz _fizzBuzz = null;

        [SetUp]
        public void Setup()
        {
            _fizzBuzz = new FizzBuzz();
        }

        [Test]
        public void LuodaanFizzBuzzLuokka()
        {
            var _fizzBuzz = new FizzBuzz();

            Assert.IsInstanceOf<FizzBuzz>(_fizzBuzz);
        }

        [Test]
        public void TulostaLukuKunSy�teOnYksi()
        {
            string vastaus = _fizzBuzz.Luku(1);

            Assert.AreEqual("1", vastaus);
        }

        [Test]
        public void TulostaLukuKunSy�teOnKaksi()
        {
            string vastaus = _fizzBuzz.Luku(2);

            Assert.AreEqual("2", vastaus);
        }

        [Test]
        public void TulostaFizzJosLukuOnKolmellaJaollinen()
        {
            string vastaus = _fizzBuzz.Luku(3);

            Assert.AreEqual("Fizz", vastaus);
        }

        [Test]
        public void TulostaFizzJosLukuOnViidell�Jaollinen()
        {
            string vastaus = _fizzBuzz.Luku(5);

            Assert.AreEqual("Buzz", vastaus);
        }

        [Test]
        public void TulostaLukuKunSy�teOnKuusi()
        {
            string vastaus = _fizzBuzz.Luku(6);

            Assert.AreEqual("Fizz", vastaus);
        }

        [Test]
        public void TulostaFizzBuzzJosLukuOnKolmellaJaViidell�Jaollinen()
        {
            string vastaus = _fizzBuzz.Luku(15);

            Assert.AreEqual("FizzBuzz", vastaus);
        }
    }
}