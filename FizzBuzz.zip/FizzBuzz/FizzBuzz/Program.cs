﻿using FizzBuzzTest;
using System;

namespace FizzBuzzHarjoitus
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("FizzBuzz -harjoitus");
            Console.WriteLine("===================");
            Console.WriteLine("Anna luku väliltä 1-100 ja paina Enter.");

            int kayttajanSyote = int.Parse(Console.ReadLine());

            var _fizzBuzz = new FizzBuzz();
            var vastaus = _fizzBuzz.Luku(kayttajanSyote);

            Console.WriteLine();
            Console.WriteLine(vastaus);
        }
    }
}
