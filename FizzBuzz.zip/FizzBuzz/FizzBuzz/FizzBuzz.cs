﻿namespace FizzBuzzTest
{
    public class FizzBuzz
    {
        public FizzBuzz()
        {
        }

        public string Luku(int syote)
        {
            if (OnkoJaollinenViidellätoista(syote))
            {
                return "FizzBuzz";
            }

            if (OnkoJaollinenKolmella(syote))
            {
                return "Fizz";
            }

            if (OnkoJaollinenViidellä(syote))
            {
                return "Buzz";
            }

            return syote.ToString();
        }

        private static bool OnkoJaollinenViidellätoista(int syote)
        {
            return OnkoJaollinenKolmella(syote) && OnkoJaollinenViidellä(syote);
        }

        private static bool OnkoJaollinenKolmella(int syote)
        {
            return syote % 3 == 0;
        }

        private static bool OnkoJaollinenViidellä(int syote)
        {
            return syote % 5 == 0;
        }
    }
}